﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnagramChecker
{
    public class Anagramy
    {
        public bool AreAnagrams(string word1, string word2)
        {
            word1 = CleanAndSortWord(word1);
            word2 = CleanAndSortWord(word2);

            return word1 == word2;
        }

        private string CleanAndSortWord(string word)
        {
            word = word.Replace(" ", "").ToLower();
            char[] wordArray = word.ToCharArray();
            Array.Sort(wordArray);
            return new string(wordArray);
        }
    }
}
