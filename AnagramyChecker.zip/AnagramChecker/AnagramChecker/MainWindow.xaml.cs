﻿using System.Windows;

namespace AnagramChecker
{
    public partial class MainWindow : Window
    {
        private Anagramy anagramChecker;

        public MainWindow()
        {
            InitializeComponent();
            anagramChecker = new Anagramy();
        }

        private void CheckAnagramClick(object sender, RoutedEventArgs e)
        {
            string word1 = textBox1.Text;
            string word2 = textBox2.Text;

            bool areAnagrams = anagramChecker.AreAnagrams(word1, word2);

            if (areAnagrams)
            {
                MessageBox.Show("Słowa są anagramami.");
            }
            else
            {
                MessageBox.Show("Słowa nie są anagramami.");
            }
        }
    }
}
